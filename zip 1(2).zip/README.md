# SL LearnMate — Grow Together.

Flutter Android learning app for text-based PDF books.

## Features
- Pick a PDF and extract selectable text.
- Basic chapter/section heading detection.
- English-to-Myanmar translation button using the public MyMemory translation API (`en|my`).
- Save each completed chapter translation locally using SharedPreferences; cached translations can be reopened offline until app data is cleared or the app is uninstalled.
- Original English is kept visible alongside the Burmese translation.
- Common science terms found in the chapter are shown in a bilingual glossary (for example, အား (Force)).
- Local notes.

## Important translation limitations
- Translation requires internet the first time. Only successfully translated content is cached for offline reading.
- MyMemory is a third-party public service. Its free anonymous allowance is limited (currently documented as 5,000 characters/day); the service may change limits, availability, or supported language quality. A whole large book may need to be translated over multiple days.
- Machine translation can be inaccurate. Always compare scientific definitions, formulas, units, and important statements with the original English.
- No guarantee of 100% accuracy. The app does not generate explanations beyond the source text.
- Scanned/image-only PDFs need OCR; OCR is not included.
- Translation is not available offline until the relevant chapter has been translated and saved.

## Build
The separate GitHub Actions workflow creates the Android platform scaffold, fetches Flutter packages, and builds a release APK.
