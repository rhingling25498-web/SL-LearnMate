import 'dart:io';
import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const LearnMateApp());
}

class LearnMateApp extends StatelessWidget {
  const LearnMateApp({super.key});

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF10233F);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SL LearnMate',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2D8C83)),
        scaffoldBackgroundColor: const Color(0xFFF5F7FA),
        appBarTheme: const AppBarTheme(
          backgroundColor: navy,
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class BookChapter {
  final String title;
  final String content;
  final int page;
  const BookChapter(this.title, this.content, this.page);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String? _filePath;
  String _fileName = '';
  bool _busy = false;
  String _status = 'PDF စာအုပ်တစ်အုပ်ကို ရွေးပြီး စတင်လေ့လာပါ။';
  List<BookChapter> _chapters = [];
  List<String> _notes = [];
  int _selectedTab = 0;

  @override
  void initState() {
    super.initState();
    _loadNotes();
  }

  Future<void> _loadNotes() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() => _notes = prefs.getStringList('notes') ?? []);
  }

  Future<void> _saveNote(String note) async {
    final prefs = await SharedPreferences.getInstance();
    _notes.insert(0, note);
    await prefs.setStringList('notes', _notes);
    if (mounted) setState(() {});
  }

  Future<void> _pickPdf() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      withData: false,
    );
    if (result == null || result.files.single.path == null) return;
    setState(() {
      _filePath = result.files.single.path;
      _fileName = result.files.single.name;
      _busy = true;
      _status = 'PDF ကို ဖတ်ရှုနေပါတယ်...';
      _chapters = [];
    });
    await _extractChapters(_filePath!);
  }

  Future<void> _extractChapters(String path) async {
    try {
      final bytes = await File(path).readAsBytes();
      final document = PdfDocument(inputBytes: bytes);
      final extractor = PdfTextExtractor(document);
      final pages = <String>[];
      for (var i = 0; i < document.pages.count; i++) {
        pages.add(extractor.extractText(startPageIndex: i, endPageIndex: i));
      }
      document.dispose();

      final full = pages.join('\n');
      final lines = full.split(RegExp(r'\r?\n'));
      final heading = RegExp(
        r'^\s*(chapter\s+[\w\dIVX.-]+|unit\s+[\w\dIVX.-]+|အခန်း\s*[\d၀-၉]+|lesson\s+[\w\d.-]+)\b.*$',
        caseSensitive: false,
      );
      final starts = <int>[];
      for (var i = 0; i < lines.length; i++) {
        if (heading.hasMatch(lines[i].trim())) starts.add(i);
      }

      final found = <BookChapter>[];
      if (starts.isEmpty) {
        found.add(BookChapter('စာအုပ်အကြောင်းအရာ', full.trim(), 1));
      } else {
        for (var j = 0; j < starts.length; j++) {
          final start = starts[j];
          final end = j + 1 < starts.length ? starts[j + 1] : lines.length;
          final content = lines.sublist(start, end).join('\n').trim();
          if (content.isNotEmpty) {
            found.add(BookChapter(lines[start].trim(), content, 1));
          }
        }
        if (starts.first > 0) {
          final intro = lines.sublist(0, starts.first).join('\n').trim();
          if (intro.isNotEmpty) {
            found.insert(0, BookChapter('အစပိုင်း / မာတိကာ', intro, 1));
          }
        }
      }

      if (!mounted) return;
      setState(() {
        _chapters = found;
        _busy = false;
        _status = found.isEmpty
            ? 'စာသားမတွေ့ပါ။ Scan PDF ဖြစ်ပါက OCR လိုအပ်နိုင်ပါတယ်။'
            : '${pages.length} မျက်နှာမှ Chapter/Section ${found.length} ခု ရှာတွေ့ပါတယ်။';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _status = 'PDF ဖတ်မရပါ။ အခြား PDF ဖြင့် စမ်းကြည့်ပါ။';
      });
    }
  }

  void _showChapter(BookChapter chapter) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChapterPage(chapter: chapter, onSave: _saveNote),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('SL LearnMate', style: TextStyle(fontWeight: FontWeight.bold)),
            Text('Grow Together.', style: TextStyle(fontSize: 12, color: Color(0xFFD5E7E4))),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'PDF ရွေးရန်',
            onPressed: _busy ? null : _pickPdf,
            icon: const Icon(Icons.upload_file),
          ),
        ],
      ),
      body: _selectedTab == 0 ? _homeBody() : _notesBody(),
      floatingActionButton: _selectedTab == 0
          ? FloatingActionButton.extended(
              onPressed: _busy ? null : _pickPdf,
              icon: const Icon(Icons.picture_as_pdf),
              label: const Text('PDF တင်မယ်'),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedTab,
        onDestinationSelected: (v) => setState(() => _selectedTab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.menu_book), label: 'စာအုပ်'),
          NavigationDestination(icon: Icon(Icons.bookmark), label: 'မှတ်စု'),
        ],
      ),
    );
  }

  Widget _homeBody() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 100),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              colors: [Color(0xFF10233F), Color(0xFF236B70)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.auto_stories, color: Colors.white, size: 34),
              SizedBox(height: 12),
              Text('Learn smarter, grow together.',
                  style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
              SizedBox(height: 6),
              Text('သင့်စာအုပ်ကို တင်ပြီး Chapter များ ခွဲကာ လေ့လာပါ။',
                  style: TextStyle(color: Colors.white70)),
            ],
          ),
        ),
        const SizedBox(height: 18),
        if (_fileName.isNotEmpty)
          Card(
            child: ListTile(
              leading: const Icon(Icons.picture_as_pdf, color: Colors.red, size: 32),
              title: Text(_fileName, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text(_status),
              trailing: _busy
                  ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
                  : IconButton(onPressed: _pickPdf, icon: const Icon(Icons.refresh)),
            ),
          )
        else
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  const Icon(Icons.cloud_upload_outlined, size: 46, color: Color(0xFF398C83)),
                  const SizedBox(height: 8),
                  const Text('PDF စာအုပ် မတင်ရသေးပါ', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 5),
                  Text(_status, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: _busy ? null : _pickPdf,
                    icon: const Icon(Icons.add),
                    label: const Text('PDF ရွေးမယ်'),
                  ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 18),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Chapter များ', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('${_chapters.length} ခု', style: const TextStyle(color: Colors.black54)),
          ],
        ),
        const SizedBox(height: 8),
        if (_chapters.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Text('PDF တင်ပြီးနောက် တွေ့ရှိသော Chapter များ ဒီနေရာတွင် ပေါ်လာပါမယ်။',
                textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
          )
        else
          ..._chapters.asMap().entries.map((entry) => Card(
                child: ListTile(
                  leading: CircleAvatar(child: Text('${entry.key + 1}')),
                  title: Text(entry.value.title, maxLines: 2, overflow: TextOverflow.ellipsis),
                  subtitle: Text('${entry.value.content.length} characters'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _showChapter(entry.value),
                ),
              )),
        const SizedBox(height: 16),
        const Text('ဘာသာရပ်များ', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _SubjectChip('English', Icons.language),
            _SubjectChip('Physics', Icons.science),
            _SubjectChip('Chemistry', Icons.biotech),
            _SubjectChip('Mathematics', Icons.calculate),
            _SubjectChip('Biology', Icons.eco),
          ],
        ),
        const SizedBox(height: 12),
        const Text(
          'မှတ်ချက် - လက်ရှိဗားရှင်းသည် PDF မှ စာသားထုတ်ယူပြီး ခေါင်းစဉ်ပုံစံများအလိုက် Chapter ခွဲပေးသည့် အခြေခံဗားရှင်းဖြစ်သည်။ Scan PDF အတွက် OCR နှင့် မြန်မာဘာသာပြန်/Local AI Model ကို နောက်အဆင့်တွင် ထည့်သွင်းရမည်။',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
      ],
    );
  }

  Widget _notesBody() {
    return _notes.isEmpty
        ? const Center(child: Text('မှတ်စု မရှိသေးပါ။ Chapter ထဲမှ မှတ်စုသိမ်းနိုင်ပါတယ်။'))
        : ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: _notes.length,
            itemBuilder: (_, i) => Card(
              child: ListTile(
                leading: const Icon(Icons.sticky_note_2_outlined),
                title: Text(_notes[i]),
              ),
            ),
          );
  }
}

class _SubjectChip extends StatelessWidget {
  final String label;
  final IconData icon;
  const _SubjectChip(this.label, this.icon);
  @override
  Widget build(BuildContext context) => Chip(avatar: Icon(icon, size: 18), label: Text(label));
}

class ChapterPage extends StatefulWidget {
  final BookChapter chapter;
  final Future<void> Function(String) onSave;
  const ChapterPage({super.key, required this.chapter, required this.onSave});

  @override
  State<ChapterPage> createState() => _ChapterPageState();
}

class _ChapterPageState extends State<ChapterPage> {
  final TextEditingController _noteController = TextEditingController();
  String? _translation;
  bool _translating = false;
  String? _translationError;

  String get _cacheKey {
    final bytes = utf8.encode('${widget.chapter.title}\n${widget.chapter.content}');
    return 'translation_${sha256.convert(bytes)}';
  }

  @override
  void initState() {
    super.initState();
    _loadCachedTranslation();
  }

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _loadCachedTranslation() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_cacheKey);
    if (mounted && saved != null && saved.trim().isNotEmpty) {
      setState(() => _translation = saved);
    }
  }

  List<String> _makeChunks(String text) {
    // MyMemory's documented request limit is 500 bytes; keep requests well below it.
    final words = text.replaceAll('\r', '').split(RegExp(r'\s+'));
    final chunks = <String>[];
    var current = '';
    for (final word in words) {
      if (word.isEmpty) continue;
      final candidate = current.isEmpty ? word : '$current $word';
      if (utf8.encode(candidate).length > 350 && current.isNotEmpty) {
        chunks.add(current);
        current = word;
      } else {
        current = candidate;
      }
    }
    if (current.isNotEmpty) chunks.add(current);
    return chunks;
  }

  Future<String> _translateChunk(String chunk) async {
    final uri = Uri.https('api.mymemory.translated.net', '/get', {
      'q': chunk,
      'langpair': 'en|my',
      'mt': '1',
    });
    final response = await http.get(uri).timeout(const Duration(seconds: 25));
    if (response.statusCode != 200) {
      throw Exception('ဘာသာပြန်ဝန်ဆောင်မှုမှ ${response.statusCode} ပြန်လာပါတယ်။');
    }
    final data = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final status = data['responseStatus'];
    final translated = (data['responseData']?['translatedText'] ?? '').toString();
    if (status != 200 || translated.trim().isEmpty) {
      final details = data['responseDetails']?.toString() ?? 'ဘာသာပြန်မရပါ။';
      throw Exception(details);
    }
    return translated
        .replaceAll('&amp;', '&')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>');
  }

  Future<void> _translateAndSave() async {
    if (_translating || widget.chapter.content.trim().isEmpty) return;
    setState(() {
      _translating = true;
      _translationError = null;
    });
    try {
      final chunks = _makeChunks(widget.chapter.content);
      final translatedParts = <String>[];
      for (var i = 0; i < chunks.length; i++) {
        if (!mounted) return;
        setState(() => _translationError = 'ဘာသာပြန်နေပါတယ်... ${i + 1}/${chunks.length}');
        translatedParts.add(await _translateChunk(chunks[i]));
        // Avoid sending requests too quickly to the free public service.
        if (i + 1 < chunks.length) {
          await Future<void>.delayed(const Duration(milliseconds: 350));
        }
      }
      final result = translatedParts.join('\n');
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_cacheKey, result);
      if (!mounted) return;
      setState(() {
        _translation = result;
        _translationError = null;
        _translating = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('မြန်မာဘာသာပြန်ကို ဖုန်းထဲတွင် သိမ်းပြီးပါပြီ။ Offline ဖတ်နိုင်ပါပြီ။')),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _translating = false;
        _translationError = 'ဘာသာပြန်မအောင်မြင်ပါ။ အင်တာနက် သို့မဟုတ် အခမဲ့ဝန်ဆောင်မှု ကန့်သတ်ချက်ကို စစ်ဆေးပါ။\n$e';
      });
    }
  }

  List<String> _glossaryTerms() {
    const terms = <String, String>{
      'Force': 'အား',
      'Mass': 'ဒြပ်ထု',
      'Acceleration': 'အရှိန်ပြောင်းနှုန်း',
      'Velocity': 'အလျင်',
      'Speed': 'အမြန်နှုန်း',
      'Energy': 'စွမ်းအင်',
      'Work': 'အလုပ်',
      'Power': 'စွမ်းအား',
      'Atom': 'အက်တမ်',
      'Molecule': 'မော်လီကျူး',
      'Cell': 'ဆဲလ်',
      'Photosynthesis': 'အလင်းဖြင့်အစာချက်လုပ်ခြင်း',
      'Gravity': 'ဆွဲငင်အား',
      'Pressure': 'ဖိအား',
      'Temperature': 'အပူချိန်',
      'Density': 'သိပ်သည်းဆ',
    };
    return terms.entries
        .where((e) => RegExp('\\b${RegExp.escape(e.key)}\\b', caseSensitive: false)
            .hasMatch(widget.chapter.content))
        .map((e) => '${e.value} (${e.key})')
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final glossary = _glossaryTerms();
    return Scaffold(
      appBar: AppBar(title: Text(widget.chapter.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('မူရင်း English', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: SelectableText(
                widget.chapter.content.isEmpty ? 'စာသားမတွေ့ပါ။' : widget.chapter.content,
                style: const TextStyle(fontSize: 16, height: 1.65),
              ),
            ),
          ),
          const SizedBox(height: 14),
          const Padding(
            padding: EdgeInsets.only(bottom: 8),
            child: Text(
              'ပထမဆုံးဘာသာပြန်ချိန်တွင် အင်တာနက်လိုအပ်သည်။ အခမဲ့ဝန်ဆောင်မှုတွင် တစ်နေ့စာအသုံးပြုခွင့် ကန့်သတ်ချက်ရှိနိုင်သည်။',
              style: TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ),
          FilledButton.icon(
            onPressed: _translating ? null : _translateAndSave,
            icon: _translating
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : Icon(_translation == null ? Icons.translate : Icons.refresh),
            label: Text(_translating ? 'မြန်မာပြန်နေပါတယ်...' : _translation == null ? 'မြန်မာပြန်ပြီး သိမ်းမယ်' : 'ဘာသာပြန်ကို ထပ်လုပ်မယ်'),
          ),
          if (_translationError != null) ...[
            const SizedBox(height: 8),
            Text(_translationError!, style: TextStyle(color: _translationError!.startsWith('ဘာသာပြန်နေပါတယ်') ? Colors.blueGrey : Colors.red)),
          ],
          if (_translation != null) ...[
            const SizedBox(height: 14),
            Row(children: [
              const Expanded(child: Text('မြန်မာဘာသာပြန်', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18))),
              Chip(avatar: const Icon(Icons.offline_pin, size: 17), label: const Text('Offline ရ')), 
            ]),
            Card(
              color: const Color(0xFFEAF5F2),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: SelectableText(_translation!, style: const TextStyle(fontSize: 16, height: 1.8)),
              ),
            ),
            if (glossary.isNotEmpty) ...[
              const SizedBox(height: 8),
              const Text('ဒီအခန်းထဲက အဓိကဝေါဟာရများ', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Wrap(spacing: 6, runSpacing: 6, children: glossary.map((term) => Chip(label: Text(term))).toList()),
            ],
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text('မှတ်ချက် - အလိုအလျောက်ဘာသာပြန်ဖြစ်သောကြောင့် အရေးကြီးသော သိပ္ပံအဓိပ္ပာယ်များကို မူရင်း English နှင့် ယှဉ်ဖတ်ပါ။',
                  style: TextStyle(fontSize: 12, color: Colors.black54)),
            ),
          ],
          const SizedBox(height: 20),
          const Text('ကိုယ်ပိုင်မှတ်စု', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          const SizedBox(height: 8),
          TextField(
            controller: _noteController,
            minLines: 3,
            maxLines: 6,
            decoration: const InputDecoration(
              hintText: 'ဒီ Chapter အတွက် မှတ်စုရေးပါ...',
              border: OutlineInputBorder(),
              filled: true,
              fillColor: Colors.white,
            ),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () async {
              if (_noteController.text.trim().isEmpty) return;
              await widget.onSave('${widget.chapter.title}\n${_noteController.text.trim()}');
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('မှတ်စု သိမ်းပြီးပါပြီ။')));
                _noteController.clear();
              }
            },
            icon: const Icon(Icons.save),
            label: const Text('မှတ်စု သိမ်းမယ်'),
          ),
        ],
      ),
    );
  }
}
